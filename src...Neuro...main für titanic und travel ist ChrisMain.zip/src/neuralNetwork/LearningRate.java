package neuralNetwork;
/// ----------------------------------------------------------------------------------------
/// This interface describes the LearningRate
/// ----------------------------------------------------------------------------------------

public interface LearningRate 
{
	// returns learning rate
	public float getLearningRate();
}
